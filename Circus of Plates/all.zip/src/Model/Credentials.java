/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Model;

/**
 *
 * @author ADMIN
 */
public interface Credentials {
    String pinkpath="/pink.png";
    String brownpath="/brown.png";
    String blackpath="/black.png";
    String bluepath="/blue.png";
    String bomb="/bomb.png";
    String background="/backgroud.png";
    String star="/star.png";
    String clown="/clown1.png";
    String heart="/myheart.png";
    final int screenHeight = 500;
    final int screenWidth = 800;
    final int platewidth=70;
    final int plateheight=10;
}
