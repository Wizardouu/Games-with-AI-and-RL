/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

//import Model.FallingPlate;
import Model.PlateObject;
import Model.AbstractFactory;

/**
 *
 * @author ADMIN
 */
public class PlateDirector {
    //Aggregation
    AbstractFactory platebuilder;
    PlateObject product;
    public PlateObject getplate(){
  return  product;
    }
    public void constructplate(String color,int posX,int posY){
       product = AbstractFactory.createplate(color, posX, posY);
    
    }
    
}
